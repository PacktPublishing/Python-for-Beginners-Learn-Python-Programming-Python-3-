#!/usr/bin/env python3


def say_hi(first, last='Doe'):
    """Say hello."""
    print('Hi {} {}!'.format(first, last))

help(say_hi)
