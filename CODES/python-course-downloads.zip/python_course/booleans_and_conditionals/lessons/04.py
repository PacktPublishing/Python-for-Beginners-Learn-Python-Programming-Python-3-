#!/usr/bin/env python3

age = 31
if age >= 35:
    print('You are old enough to be the President.')

print('Have a nice day!')
