#!/usr/bin/env python3

with open('file.txt') as the_file:
    for line in the_file:
        print(line.rstrip())
