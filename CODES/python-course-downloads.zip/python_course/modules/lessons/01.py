#!/usr/bin/env python3

import time
print(time.asctime())
print(time.timezone)
