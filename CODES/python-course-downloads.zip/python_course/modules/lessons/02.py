#!/usr/bin/env python3

from time import asctime
print(asctime())
