#!/usr/bin/env python3


def say_hi():
    print('Hi!')


def main():
    print('Hello from say_hi3.py!')
    say_hi()

if __name__ == '__main__':
    main()
