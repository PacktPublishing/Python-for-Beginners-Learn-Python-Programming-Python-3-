#!/usr/bin/env python3

from time import asctime, sleep
print(asctime())
sleep(3)
print(asctime())
