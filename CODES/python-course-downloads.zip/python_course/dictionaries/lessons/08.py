#!/usr/bin/env python3

contacts = {
    'Jason': ['555-0123', '555-0000'],
    'Carl': '555-0987'
}

print ('555-0987' in contacts.values())
