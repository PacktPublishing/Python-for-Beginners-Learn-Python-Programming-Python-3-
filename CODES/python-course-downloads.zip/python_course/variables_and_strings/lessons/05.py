#!/usr/bin/env python3
fruit = "apple"
