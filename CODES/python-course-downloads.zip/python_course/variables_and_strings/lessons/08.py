#!/usr/bin/env python3
sentence_in_double = "She said, \"That's a great tasting apple!\""
sentence_in_single = 'She said, "That\'s a great tasting apple!"'
