#!/usr/bin/env python3
first = 'I'
second = 'love'
third = 'Python'
sentence = first + ' ' + second + ' ' + third + '.'
print(sentence)
