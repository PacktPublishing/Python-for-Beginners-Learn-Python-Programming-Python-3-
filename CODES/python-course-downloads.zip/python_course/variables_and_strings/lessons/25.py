#!/usr/bin/env python3
print('I {0} {1}.  {1} {0}s me.'.format('love', 'Python'))
