#!/usr/bin/env python3
fruit = 'apple'
print(fruit)
print('orange')
