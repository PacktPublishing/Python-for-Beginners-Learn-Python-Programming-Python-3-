#!/usr/bin/env python3
version = 3
print('I love Python ' + str(version) + '.')
