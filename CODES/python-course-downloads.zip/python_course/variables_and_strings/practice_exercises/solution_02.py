#!/usr/bin/env python3
user_input = input('Please type something and press enter: ')
print('You entered:')
print(user_input)
