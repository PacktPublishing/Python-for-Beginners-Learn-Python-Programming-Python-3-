#!/usr/bin/env python3

quantity_string = '3'
total = quantity_string + 2
