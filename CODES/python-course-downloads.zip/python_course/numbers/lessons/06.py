#!/usr/bin/env python3

quantity_string = '3'
total = int(quantity_string) + 2
print(total)
