#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
cat_index = animals.index('cat')
print(cat_index)
